import 'package:flutter/material.dart';

import '../common/error_card.dart';
import '../common/loading_card.dart';
import '../watchlist_card.dart';

class WatchlistSection extends StatelessWidget {
  final bool loading;
  final String? error;
  final List<dynamic>? watchlist;

  const WatchlistSection({
    super.key,
    required this.loading,
    required this.watchlist,
    this.error,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const LoadingCard(
        message: "Loading Watchlist...",
      );
    }

    if (error != null) {
      return ErrorCard(
        message: error!,
      );
    }

    if (watchlist == null || watchlist!.isEmpty) {
      return const ErrorCard(
        message: "Your watchlist is empty.",
      );
    }

    return Column(
      children: watchlist!
          .map(
            (item) => Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: WatchlistCard(
                symbol: item["symbol"] ?? "--",
                lastPrice:
                    ((item["last_price"] ?? 0) as num)
                        .toDouble(),
                change:
                    ((item["change"] ?? 0) as num)
                        .toDouble(),
                changePercent:
                    ((item["change_percent"] ?? 0) as num)
                        .toDouble(),
              ),
            ),
          )
          .toList(),
    );
  }
}
import 'package:flutter/material.dart';

import '../cards/holdings_card.dart';
import '../common/error_card.dart';
import '../common/loading_card.dart';

class HoldingsSection extends StatelessWidget {
  final bool loading;
  final String? error;
  final List<dynamic>? holdings;

  const HoldingsSection({
    super.key,
    required this.loading,
    required this.holdings,
    this.error,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const LoadingCard(
        message: "Loading Holdings...",
      );
    }

    if (error != null) {
      return ErrorCard(
        message: error!,
      );
    }

    if (holdings == null || holdings!.isEmpty) {
      return const ErrorCard(
        message: "No holdings found.",
      );
    }

    return Column(
      children: holdings!
          .map(
            (item) => Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: HoldingsCard(
                symbol: item["trading_symbol"] ??
                    item["symbol"] ??
                    "--",
                quantity:
                    (item["quantity"] ?? 0).toString(),
                averagePrice:
                    ((item["average_price"] ?? 0) as num)
                        .toDouble(),
                lastPrice:
                    ((item["last_price"] ?? 0) as num)
                        .toDouble(),
                pnl: ((item["pnl"] ?? 0) as num)
                    .toDouble(),
              ),
            ),
          )
          .toList(),
    );
  }
}
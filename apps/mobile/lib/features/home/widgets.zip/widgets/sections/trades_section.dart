import 'package:flutter/material.dart';

import '../cards/trades_card.dart';
import '../common/error_card.dart';
import '../common/loading_card.dart';

class TradesSection extends StatelessWidget {
  final bool loading;
  final String? error;
  final List<dynamic>? trades;

  const TradesSection({
    super.key,
    required this.loading,
    required this.trades,
    this.error,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const LoadingCard(
        message: "Loading Trades...",
      );
    }

    if (error != null) {
      return ErrorCard(
        message: error!,
      );
    }

    if (trades == null || trades!.isEmpty) {
      return const ErrorCard(
        message: "No trades available.",
      );
    }

    return Column(
      children: trades!
          .map(
            (item) => Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: TradesCard(
                symbol: item["trading_symbol"] ??
                    item["symbol"] ??
                    "--",
                transactionType:
                    item["transaction_type"] ?? "--",
                quantity:
                    (item["quantity"] ?? 0).toString(),
                price:
                    ((item["price"] ?? 0) as num)
                        .toDouble(),
                orderId:
                    item["order_id"]?.toString() ?? "--",
              ),
            ),
          )
          .toList(),
    );
  }
}
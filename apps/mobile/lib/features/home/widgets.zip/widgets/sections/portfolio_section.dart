import 'package:flutter/material.dart';

import '../cards/portfolio_summary_card.dart';
import '../common/error_card.dart';
import '../common/loading_card.dart';

class PortfolioSection extends StatelessWidget {
  final bool loading;
  final String? error;
  final Map<String, dynamic>? portfolio;

  const PortfolioSection({
    super.key,
    required this.loading,
    required this.portfolio,
    this.error,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const LoadingCard(
        message: "Loading Portfolio...",
      );
    }

    if (error != null) {
      return ErrorCard(
        message: error!,
      );
    }

    if (portfolio == null) {
      return const ErrorCard(
        message: "Portfolio data unavailable",
      );
    }

    final totalValue =
        (portfolio!["totalValue"] ?? 0).toDouble();

    final invested =
        (portfolio!["invested"] ?? 0).toDouble();

    final pnl =
        (portfolio!["pnl"] ?? 0).toDouble();

    final pnlPercent =
        (portfolio!["pnlPercent"] ?? 0).toDouble();

    return PortfolioSummaryCard(
      totalValue: totalValue,
      invested: invested,
      pnl: pnl,
      pnlPercent: pnlPercent,
    );
  }
}
import 'package:flutter/material.dart';

import '../cards/positions_card.dart';
import '../common/error_card.dart';
import '../common/loading_card.dart';

class PositionsSection extends StatelessWidget {
  final bool loading;
  final String? error;
  final List<dynamic>? positions;

  const PositionsSection({
    super.key,
    required this.loading,
    required this.positions,
    this.error,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const LoadingCard(
        message: "Loading Positions...",
      );
    }

    if (error != null) {
      return ErrorCard(
        message: error!,
      );
    }

    if (positions == null || positions!.isEmpty) {
      return const ErrorCard(
        message: "No open positions.",
      );
    }

    return Column(
      children: positions!
          .map(
            (item) => Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: PositionsCard(
                symbol: item["trading_symbol"] ??
                    item["symbol"] ??
                    "--",
                product: item["product"] ?? "--",
                quantity:
                    (item["quantity"] ?? 0).toString(),
                averagePrice:
                    ((item["average_price"] ?? 0) as num)
                        .toDouble(),
                lastPrice:
                    ((item["last_price"] ?? 0) as num)
                        .toDouble(),
                pnl: ((item["pnl"] ?? 0) as num)
                    .toDouble(),
              ),
            ),
          )
          .toList(),
    );
  }
}